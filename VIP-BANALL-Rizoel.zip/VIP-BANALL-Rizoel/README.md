# Ban All Bot

- This is a Sudo Based Members Banning Bot 
 
# Commands
- ping
- banall
- unbanall
- kickall
- leave 
- restart

# Deploy To Heroku 🚀
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=[https://github.com/team-katil/BanallBot](https://github.com/THE-VIP-BOY-OP/VIP-BANALL))

# Credits
* [RiZoeL](https://github.com/MrRizoel)
* [Lonami](https://github.com/LonamiWebs/) for [Telethon.](https://github.com/LonamiWebs/Telethon)
